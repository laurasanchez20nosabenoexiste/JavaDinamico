// Array donde se van a almacenar los nuevos estudiantes.
let usuariosGuardados = []; // Este array almacena objetos que representan a los estudiantes guardados.

// Espera a que el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", function() {
    // Asigna el evento de clic al botón "Generar Formulario"
    document.getElementById("generarBtn").addEventListener("click", generarFormulario); // Genera el formulario dinámico al hacer clic.
    // Asigna el evento de clic al botón "Consultar"
    document.getElementById("consultarBtn").addEventListener("click", consultarEstudiante); // Consulta un estudiante al hacer clic.
    // Asigna el evento de clic al botón "Guardar Usuarios"
    document.getElementById("guardarBtn").addEventListener("click", guardarUsuarios); // Guarda los usuarios al hacer clic.
});

// Función para generar el formulario dinámico
function generarFormulario() {
    // Obtiene el número de estudiantes ingresado
    let num = parseInt(document.getElementById('numEstudiantes').value); // Convierte el valor del input a un número entero.
    // Obtiene el contenedor donde se generarán los campos
    let contenedor = document.getElementById('contenedorEstudiantes'); // Elemento HTML donde se mostrarán los campos.
    // Limpia el contenido previo del contenedor
    contenedor.innerHTML = ''; // Elimina cualquier contenido existente en el contenedor.

    // Valida que el número ingresado sea válido
    if (isNaN(num) || num <= 0) { // Verifica si el número es NaN (Not a Number) o menor o igual a cero.
        alert("Ingrese un número válido de estudiantes."); // Muestra un mensaje de error si el número no es válido.
        return; // Sale de la función si el número no es válido.
    }

    // Genera los campos para cada estudiante
    for (let i = 0; i < num; i++) { // Bucle que se ejecuta 'num' veces.
        let div = document.createElement('div'); // Crea un nuevo elemento div.
        div.classList.add('estudiante'); // Agrega la clase 'estudiante' al div.
        div.innerHTML = `
            <h3>Estudiante ${i + 1}</h3> 
            <label>Nombre:</label> 
            <input type="text" name="nombre${i}" required> 
            <label>Apellido:</label> 
            <input type="text" name="apellido${i}" required> 
            <label>Tipo de Identificación:</label> 
            <select name="tipoIdentificacion${i}"> 
                <option value="cedula">Cédula</option> 
                <option value="tarjeta">Tarjeta de Identidad</option> 
                <option value="cedulaE">Cédula de Extranjería</option> 
                <option value="pasaporte">Pasaporte</option> 
            </select>
            <label>Número de Identificación:</label> 
            <input type="text" name="identificacion${i}" required> 
            <label>Correo Institucional:</label> 
            <input type="email" name="correo${i}" required> 
        `;
        contenedor.appendChild(div); // Agrega el div al contenedor.
    }
}

// Función para guardar los usuarios
function guardarUsuarios() {
    // Obtiene todos los campos de estudiantes
    let estudiantes = document.querySelectorAll('.estudiante'); // Selecciona todos los elementos con la clase 'estudiante'.

    estudiantes.forEach(estudiante => { // Bucle que itera sobre cada estudiante.
        let nombre = estudiante.querySelector('[name^="nombre"]').value; // Obtiene el valor del campo de nombre.
        let apellido = estudiante.querySelector('[name^="apellido"]').value; // Obtiene el valor del campo de apellido.
        let tipoIdentificacion = estudiante.querySelector('[name^="tipoIdentificacion"]').value; // Obtiene el valor del campo de tipo de identificación.
        let identificacion = estudiante.querySelector('[name^="identificacion"]').value; // Obtiene el valor del campo de número de identificación.
        let correo = estudiante.querySelector('[name^="correo"]').value; // Obtiene el valor del campo de correo electrónico.

        // Verifica si el usuario ya existe
        let existe = usuariosGuardados.some(usuario => usuario.identificacion === identificacion); // Busca si ya hay un usuario con la misma identificación en el array.
        if (!existe) { // Si no existe el usuario.
            // Guarda el usuario en el array
            usuariosGuardados.push({ // Agrega un nuevo objeto al array.
                nombre, // Propiedad 'nombre' del objeto.
                apellido, // Propiedad 'apellido' del objeto.
                tipoIdentificacion, // Propiedad 'tipoIdentificacion' del objeto.
                identificacion, // Propiedad 'identificacion' del objeto.
                correo // Propiedad 'correo' del objeto.
            });
        } else { // Si el usuario ya existe.
            alert(`El usuario con identificación ${identificacion} ya existe.`); // Muestra un mensaje de error.
        }
    });

    alert("Usuarios guardados correctamente."); // Muestra un mensaje de éxito.
    limpiarFormulario(); // Limpia el formulario después de guardar.
}

// Función para limpiar el formulario
function limpiarFormulario() {
    // Limpia el contenedor de estudiantes
    document.getElementById('contenedorEstudiantes').innerHTML = ''; // Elimina cualquier contenido en el contenedor.
    // Reinicia el campo de número de estudiantes
    document.getElementById('numEstudiantes').value = ''; // Reinicia el campo de texto.
}

// Función para consultar un estudiante por su número de identificación
function consultarEstudiante() {
    // Obtiene el número de identificación ingresado
    let idIngresado = document.getElementById('consultaID').value.trim(); // Obtiene el valor del campo de consulta y elimina espacios en blanco.
    let lista = document.getElementById('usuariosConsultados'); // Elemento HTML donde se mostrarán los resultados.
    lista.innerHTML = ''; // Limpia cualquier contenido previo en la lista.

    // Busca coincidencias parciales en el número de identificación
    usuariosGuardados.forEach(usuario => { // Bucle que itera sobre cada usuario guardado.
        if (usuario.identificacion.includes(idIngresado)) { // Verifica si el número de identificación del usuario incluye el texto ingresado.
            let li = document.createElement('li'); // Crea un nuevo elemento li.
            li.innerHTML = `
                <span>Nombre: ${usuario.nombre} ${usuario.apellido}, Identificación: ${usuario.identificacion}, Correo: ${usuario.correo}</span> 
                <button type="button" class="eliminarBtn" onclick="eliminarUsuario('${usuario.identificacion}')">Eliminar</button>`;
            lista.appendChild(li); // Agrega el elemento li a la lista.
        }
    });

    if (lista.innerHTML === '') { // Si la lista está vacía después de buscar.
        alert('No se encontraron coincidencias.'); // Muestra un mensaje de error.
    }
}

// Función para eliminar un usuario
function eliminarUsuario(identificacion) {
    // Filtra el array para eliminar el usuario con la identificación dada
    usuariosGuardados = usuariosGuardados.filter(usuario => usuario.identificacion !== identificacion); // Actualiza el array eliminando el usuario con la identificación especificada.
    alert("Usuario eliminado correctamente."); // Muestra un mensaje de éxito.
    consultarEstudiante(); // Actualiza la lista de consulta después de eliminar.
}
